import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_scatter import scatter


def segment_softmax(src, index, num_segments):
    max_per = scatter(src, index, dim=0, dim_size=num_segments, reduce="max")
    shifted = src - max_per[index]
    exp = shifted.exp()
    denom = scatter(exp, index, dim=0, dim_size=num_segments, reduce="sum")
    return exp / denom[index].clamp_min(1e-12)


class HNRD(nn.Module):
    """Hypergraph Neural Reaction-Diffusion network.

    The diffusion term follows the HND-style node-hyperedge-node attention
    operator. HNRD adds a reaction term and bounded instantaneous dissipation
    compensation on top of that diffusion backbone.
    """

    def __init__(
        self,
        in_dim: int,
        hidden_dim: int,
        out_dim: int,
        layers: int = 4,
        input_dropout: float = 0.2,
        hidden_dropout: float = 0.2,
        step_size: float = 0.5,
        learnable_step: bool = True,
    ):
        super().__init__()
        self.encoder = nn.Linear(in_dim, hidden_dim)
        self.theta = nn.Linear(hidden_dim, hidden_dim)
        self.attention = nn.Linear(hidden_dim * 2, 1)
        self.drift = nn.Linear(hidden_dim, hidden_dim)
        self.reaction = nn.Linear(hidden_dim, hidden_dim)
        self.classifier = nn.Linear(hidden_dim, out_dim)
        self.skip = nn.Linear(in_dim, out_dim)
        self.eta = nn.Parameter(torch.tensor(1.0))
        init_step = torch.tensor(float(step_size)).clamp(1e-4, 1.0 - 1e-4)
        init_logit = torch.logit(init_step)
        if learnable_step:
            self.step_logit = nn.Parameter(init_logit)
        else:
            self.register_buffer("step_logit", init_logit)
        self.layers = layers
        self.input_dropout = input_dropout
        self.hidden_dropout = hidden_dropout

    @property
    def step_size(self):
        return torch.sigmoid(self.step_logit)

    def hnd_diffusion(self, h, vertex, edges, num_edges):
        edge_state = scatter(h[vertex], edges, dim=0, dim_size=num_edges, reduce="mean")
        pair_state = torch.cat([self.theta(h[vertex]), self.theta(edge_state[edges])], dim=-1)
        score = F.leaky_relu(self.attention(pair_state), negative_slope=0.2).view(-1)

        alpha_node_to_edge = segment_softmax(score, edges, num_edges)
        edge_msg = scatter(
            alpha_node_to_edge[:, None] * h[vertex],
            edges,
            dim=0,
            dim_size=num_edges,
            reduce="sum",
        )

        alpha_edge_to_node = segment_softmax(score, vertex, h.shape[0])
        node_msg = scatter(
            alpha_edge_to_node[:, None] * edge_msg[edges],
            vertex,
            dim=0,
            dim_size=h.shape[0],
            reduce="sum",
        )
        return self.drift(node_msg - h)

    def forward(self, x, vertex, edges, num_edges, return_representation=False):
        h = F.relu(self.encoder(F.dropout(x, self.input_dropout, self.training)))
        for _ in range(self.layers):
            diffusion = self.hnd_diffusion(h, vertex, edges, num_edges)
            reaction = torch.tanh(self.reaction(h))

            q_phi_x = h - h.mean(dim=0, keepdim=True)
            q_norm2 = torch.sum(q_phi_x * q_phi_x).clamp_min(1e-12)
            instantaneous_loss = torch.sum(diffusion * q_phi_x) / q_norm2
            bounded_feedback = torch.tanh(F.softplus(self.eta) - torch.mean(q_phi_x * q_phi_x))

            h = h + self.step_size * (
                diffusion + reaction + (instantaneous_loss + bounded_feedback) * q_phi_x
            )
            h = F.dropout(F.relu(h), self.hidden_dropout, self.training)

        logits = self.classifier(h) + self.skip(x)
        if return_representation:
            return logits, h
        return logits
