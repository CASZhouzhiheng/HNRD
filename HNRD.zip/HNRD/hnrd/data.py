import os
from pathlib import Path

import numpy as np
import scipy.sparse as sp
import torch

from .utils import normalize_edges


def load_modelnet40(data_root=None):
    """Load ModelNet40 from LE-style hypergraph files.

    Expected layout:
        data_root/ModelNet40/ModelNet40.content
        data_root/ModelNet40/ModelNet40.edges

    The same loader also works for other LE-style datasets such as Zoo and
    NTU2012 by changing the dataset directory and file stem.
    """
    root = Path(data_root or os.environ.get("HNRD_DATA_ROOT", "data"))
    name = "ModelNet40"
    path = root / name
    content_path = path / f"{name}.content"
    edge_path = path / f"{name}.edges"
    if not content_path.exists() or not edge_path.exists():
        raise FileNotFoundError(
            "ModelNet40 files were not found. Expected "
            f"{content_path} and {edge_path}. Pass --data-root or set HNRD_DATA_ROOT."
        )

    content = np.genfromtxt(content_path, dtype=np.dtype(str))
    features = sp.csr_matrix(content[:, 1:-1], dtype=np.float32)
    labels = torch.as_tensor(content[:, -1].astype(float), dtype=torch.long)
    labels = labels - labels.min()

    node_ids = np.asarray(content[:, 0], dtype=np.int64)
    id_map = {old_id: new_id for new_id, old_id in enumerate(node_ids)}
    raw_edges = np.genfromtxt(edge_path, dtype=np.int64)
    if raw_edges.ndim == 1:
        raw_edges = raw_edges.reshape(1, -1)
    mapped = np.array(list(map(id_map.get, raw_edges.flatten())), dtype=np.int64).reshape(raw_edges.shape)
    edge_index = mapped.T
    num_nodes = int(edge_index[0].max() + 1)

    edge_list = []
    for edge_id in sorted(np.unique(edge_index[1])):
        nodes = np.unique(edge_index[0, edge_index[1] == edge_id]).tolist()
        edge_list.append(tuple(int(v) for v in nodes))

    return {
        "features": torch.as_tensor(features[:num_nodes].todense(), dtype=torch.float32),
        "labels": labels[:num_nodes].long(),
        "edge_list": normalize_edges(edge_list, num_nodes),
        "num_nodes": num_nodes,
        "num_classes": int(labels[:num_nodes].max().item() + 1),
    }


def load_dataset(name: str, data_root=None):
    if name != "ModelNet40":
        raise ValueError("This clean release currently ships the ModelNet40 main experiment.")
    return load_modelnet40(data_root)

